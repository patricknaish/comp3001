"""
Magic module to put appengine_utilities on the right path (ewww)
"""
import appengine_utilities

appengine_utilities = appengine_utilities
